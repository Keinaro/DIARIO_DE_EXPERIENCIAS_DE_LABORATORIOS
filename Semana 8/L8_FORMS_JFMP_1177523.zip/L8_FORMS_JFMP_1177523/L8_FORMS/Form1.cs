﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_FORMS
{
    public partial class Lab : Form
    {
        public int opcion = 0;
        public Lab()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSeleccion_Click(object sender, EventArgs e)
        {

            switch (cmbSeleccion.SelectedIndex)
            {
                case 0:
                    int inicio = 0;
                    int sum = 0;
                    int n = int.Parse(txtNumero.Text);
                    do
                    {
                        inicio++;
                        sum = sum + inicio;

                    } while (inicio < n);
                    lblResultadoFinal.Text = sum.ToString();
                    break;

                case 1:
                    int x = int.Parse(txtbtablas.Text);
                    int mult = 0;

                    for (int i = 1; i <= 100; i++)
                    {
                        mult = x * i;
                        lstbxTABLAS.Items.Add(x + " * " + i + " = " + mult);
                    }
                    break;

                case 2:
                    int n1 = 0;
                    int s = 0;
                    bool a = int.TryParse(txtbnumper.Text, out n1);
                    if (a == true)
                    {
                        if (n1 > 0)
                        {
                            for (int y = 1; y < n1; y++)
                            {
                                if (n1 % y==0)
                                {
                                    s = s + y;
                                }
                            }
                            if (s == n1)
                            { 
                                lblresultadonumper.Text=(n1 + " Es un número perfecto.");
                            }
                            else
                            {
                                lblresultadonumper.Text=(n1 + " No es un número perfecto.");
                            }
                        }
                        else
                        {
                            lblresultadonumper.Text= (n1+ " No es un número mayor a 0.");
                        }
                    }
                    else
                    {
                        lblresultadonumper.Text=(n1+" No es un número.");
                    }
                    break;
            }
            
        }

        private void cmbSeleccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cmbSeleccion.SelectedIndex)
            {
                case 0:
                    tabDatos.SelectedTab = tabPage1;
                    opcion = 1;
                    break;
                case 1:
                    tabDatos.SelectedTab = tabPage2;
                    opcion = 1;
                    break;
                case 2:
                    tabDatos.SelectedTab = tabPage3;
                    opcion = 1;
                    break;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
                  
        }

        private void lstbxTABLAS_SelectedIndexChanged(object sender, EventArgs e)
        {


        }
    }
}
