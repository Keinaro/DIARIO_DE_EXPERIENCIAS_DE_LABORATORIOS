﻿namespace L8_FORMS
{
    partial class Lab
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.seleccion = new System.Windows.Forms.GroupBox();
            this.cmbSeleccion = new System.Windows.Forms.ComboBox();
            this.btnSeleccion = new System.Windows.Forms.Button();
            this.tabDatos = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblResultadoFinal = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblIngreso = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbnumper = new System.Windows.Forms.TextBox();
            this.lblresultadonumper = new System.Windows.Forms.Label();
            this.lvlnumper = new System.Windows.Forms.Label();
            this.lstbxTABLAS = new System.Windows.Forms.ListBox();
            this.txtbtablas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.seleccion.SuspendLayout();
            this.tabDatos.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kristen ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(191, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "LABORATORIO 8";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // seleccion
            // 
            this.seleccion.Controls.Add(this.cmbSeleccion);
            this.seleccion.Controls.Add(this.btnSeleccion);
            this.seleccion.Location = new System.Drawing.Point(24, 58);
            this.seleccion.Name = "seleccion";
            this.seleccion.Size = new System.Drawing.Size(238, 77);
            this.seleccion.TabIndex = 1;
            this.seleccion.TabStop = false;
            this.seleccion.Text = "Seleccionar";
            // 
            // cmbSeleccion
            // 
            this.cmbSeleccion.AutoCompleteCustomSource.AddRange(new string[] {
            "SUMATORIA",
            "TABLAS",
            "NÚMERO PERFECTO"});
            this.cmbSeleccion.FormattingEnabled = true;
            this.cmbSeleccion.Items.AddRange(new object[] {
            "SUMATORIA",
            "TABLAS",
            "NÚMERO PERFECTO"});
            this.cmbSeleccion.Location = new System.Drawing.Point(6, 19);
            this.cmbSeleccion.Name = "cmbSeleccion";
            this.cmbSeleccion.Size = new System.Drawing.Size(226, 21);
            this.cmbSeleccion.TabIndex = 0;
            this.cmbSeleccion.SelectedIndexChanged += new System.EventHandler(this.cmbSeleccion_SelectedIndexChanged);
            // 
            // btnSeleccion
            // 
            this.btnSeleccion.Location = new System.Drawing.Point(81, 46);
            this.btnSeleccion.Name = "btnSeleccion";
            this.btnSeleccion.Size = new System.Drawing.Size(75, 23);
            this.btnSeleccion.TabIndex = 2;
            this.btnSeleccion.Text = "Seleccionar";
            this.btnSeleccion.UseVisualStyleBackColor = true;
            this.btnSeleccion.Click += new System.EventHandler(this.btnSeleccion_Click);
            // 
            // tabDatos
            // 
            this.tabDatos.Controls.Add(this.tabPage1);
            this.tabDatos.Controls.Add(this.tabPage2);
            this.tabDatos.Controls.Add(this.tabPage3);
            this.tabDatos.Location = new System.Drawing.Point(283, 58);
            this.tabDatos.Name = "tabDatos";
            this.tabDatos.SelectedIndex = 0;
            this.tabDatos.Size = new System.Drawing.Size(283, 158);
            this.tabDatos.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblResultadoFinal);
            this.tabPage1.Controls.Add(this.txtNumero);
            this.tabPage1.Controls.Add(this.lblResultado);
            this.tabPage1.Controls.Add(this.lblIngreso);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(275, 132);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SUMATORIA";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // lblResultadoFinal
            // 
            this.lblResultadoFinal.AutoSize = true;
            this.lblResultadoFinal.Location = new System.Drawing.Point(143, 85);
            this.lblResultadoFinal.Name = "lblResultadoFinal";
            this.lblResultadoFinal.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoFinal.TabIndex = 7;
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(133, 35);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(100, 20);
            this.txtNumero.TabIndex = 6;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(72, 85);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(55, 13);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = "Resultado";
            // 
            // lblIngreso
            // 
            this.lblIngreso.AutoSize = true;
            this.lblIngreso.Location = new System.Drawing.Point(42, 38);
            this.lblIngreso.Name = "lblIngreso";
            this.lblIngreso.Size = new System.Drawing.Size(85, 13);
            this.lblIngreso.TabIndex = 4;
            this.lblIngreso.Text = "Ingrese Número:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtbtablas);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.lstbxTABLAS);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(275, 132);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TABLAS";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.txtbnumper);
            this.tabPage3.Controls.Add(this.lblresultadonumper);
            this.tabPage3.Controls.Add(this.lvlnumper);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(275, 132);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "NÚMERO PERFECTO";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(143, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 15;
            // 
            // txtbnumper
            // 
            this.txtbnumper.Location = new System.Drawing.Point(133, 35);
            this.txtbnumper.Name = "txtbnumper";
            this.txtbnumper.Size = new System.Drawing.Size(100, 20);
            this.txtbnumper.TabIndex = 14;
            // 
            // lblresultadonumper
            // 
            this.lblresultadonumper.AutoSize = true;
            this.lblresultadonumper.Location = new System.Drawing.Point(72, 85);
            this.lblresultadonumper.Name = "lblresultadonumper";
            this.lblresultadonumper.Size = new System.Drawing.Size(55, 13);
            this.lblresultadonumper.TabIndex = 13;
            this.lblresultadonumper.Text = "Resultado";
            // 
            // lvlnumper
            // 
            this.lvlnumper.AutoSize = true;
            this.lvlnumper.Location = new System.Drawing.Point(42, 38);
            this.lvlnumper.Name = "lvlnumper";
            this.lvlnumper.Size = new System.Drawing.Size(85, 13);
            this.lvlnumper.TabIndex = 12;
            this.lvlnumper.Text = "Ingrese Número:";
            // 
            // lstbxTABLAS
            // 
            this.lstbxTABLAS.FormattingEnabled = true;
            this.lstbxTABLAS.Location = new System.Drawing.Point(6, 31);
            this.lstbxTABLAS.Name = "lstbxTABLAS";
            this.lstbxTABLAS.Size = new System.Drawing.Size(263, 95);
            this.lstbxTABLAS.TabIndex = 0;
            this.lstbxTABLAS.SelectedIndexChanged += new System.EventHandler(this.lstbxTABLAS_SelectedIndexChanged);
            // 
            // txtbtablas
            // 
            this.txtbtablas.Location = new System.Drawing.Point(130, 6);
            this.txtbtablas.Name = "txtbtablas";
            this.txtbtablas.Size = new System.Drawing.Size(100, 20);
            this.txtbtablas.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Ingrese Número:";
            // 
            // Lab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 245);
            this.Controls.Add(this.tabDatos);
            this.Controls.Add(this.seleccion);
            this.Controls.Add(this.label1);
            this.Name = "Lab";
            this.Text = "Laboratorio 8";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.seleccion.ResumeLayout(false);
            this.tabDatos.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox seleccion;
        private System.Windows.Forms.ComboBox cmbSeleccion;
        private System.Windows.Forms.Button btnSeleccion;
        private System.Windows.Forms.TabControl tabDatos;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lblResultadoFinal;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblIngreso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbnumper;
        private System.Windows.Forms.Label lblresultadonumper;
        private System.Windows.Forms.Label lvlnumper;
        private System.Windows.Forms.ListBox lstbxTABLAS;
        private System.Windows.Forms.TextBox txtbtablas;
        private System.Windows.Forms.Label label2;
    }
}

