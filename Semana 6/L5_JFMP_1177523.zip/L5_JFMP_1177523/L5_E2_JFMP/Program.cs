﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 2");

        int n1;

        Console.WriteLine("Ingrese el número de dia");
        bool canConvert = int.TryParse(Console.ReadLine(), out n1);
        if (canConvert == true)
        {
            switch (n1)
            {
                case 1: Console.WriteLine("DIA: Lunes");
                    break;
                case 2: Console.WriteLine("DIA: Martes");
                    break;
                case 3: Console.WriteLine("DIA: Miercoles");
                    break;
                case 4: Console.WriteLine("DIA: Jueves");
                    break;
                case 5: Console.WriteLine("DIA: Viernes");
                    break;
                case 6: Console.WriteLine("DIA: Sabado");
                    break;
                case 7: Console.WriteLine("DIA:Domingo");
                    break;
                default: Console.WriteLine("El numero a ingresar debe de estar contenido entre 1 y 7");
                    break;
            }
        }
        else
        {
            Console.WriteLine("El numero a ingresar debe de estar contenido entre 1 y 7");
        }
    }


}
