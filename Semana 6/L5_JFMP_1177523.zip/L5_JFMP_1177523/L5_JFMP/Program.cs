﻿using System;
using System.Transactions;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1");

        int n1 = 0;
        
        Console.WriteLine("Ingrese un número entero: ");
 
        bool canConvert = int.TryParse(Console.ReadLine(), out n1);
        if (canConvert == true)
        {
            if (n1 > 0)
            {
                Console.WriteLine("El número es positivo");
            }
            else if (n1 < 0)
            {
                Console.WriteLine("El número es negativo");
            }
            else if (n1 == 0)
            {
                Console.WriteLine("El número es cero");
            }
        }
        else
        {
            Console.WriteLine("ERROR");
        }








    }
    

   

}
