﻿using System;
using System.Data;
using System.Globalization;
using System.Security.Authentication;

class Program
{
    static void Main(string[] args)
    {
        string menu = "";
        while (!menu.Equals("D"))
        {
            Console.Clear();
            Console.WriteLine("Laboratorio 8 - Jorge Muñoz - 1177523\n\n");
            Console.WriteLine("Porfavor ingrese una opcion: ");

            Console.WriteLine("A. Sumatoria.");
            Console.WriteLine("B. Mostra tablas de multiplicar.");
            Console.WriteLine("C. Número Perfecto.");
            Console.WriteLine("D. Salir del programa.\n");
            Console.Write("--> ");

            string opcion = (Console.ReadLine());

            switch (opcion)
            {
                case "A" or "a":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Jorge Muñoz - 1177523\n\n");
                    Console.WriteLine("Sumatoria.\n");
                    int inicio = 0;
                    int sum = 0;
                    Console.Write("Ingrese un número: ");
                    int n = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\n");
                    do
                    {
                        inicio++;
                        Console.WriteLine(inicio);                        
                        sum = sum + inicio;
                    } while (inicio < n);
                    Console.WriteLine("\n");
                    Console.WriteLine("La suma de los números es: " + sum);

                    Console.ReadKey();
                    break;

                case "B" or "b":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Jorge Muñoz - 1177523\n\n");
                    Console.WriteLine("Tablas de multiplicar.\n");

                    Console.Write("Ingrese el número que va a multiplicar: ");
                    int x = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\n");
                    int mult;

                    for (int i = 1; i <= 10; i++)
                    {
                        mult = x * i;
                        Console.WriteLine(x + " * " + i + " = " + mult);
                    }
                    Console.WriteLine("\n");
                    Console.ReadKey();
                    break;

                case "C" or "c":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Jorge Muñoz - 1177523\n\n");
                    Console.WriteLine("Número perfecto.\n");

                    int n1 = 0;
                    int s = 0;
                    Console.Write("Ingrese un número entero: ");

                    bool a = int.TryParse(Console.ReadLine(), out n1);

                    if (a == true)
                    {
                        if (n1 > 0)
                        {
                            for (int y = 1; y < n1; y++)
                            {
                                if (n1 % y==0)
                                {
                                    s = s + y;
                                }                            
                            }
                            if (s == n1)
                            {
                                Console.WriteLine("\nEs un número perfecto.\n");
                            }
                            else
                            {
                                Console.WriteLine("\nNo es un número perfecto.\n");
                            }
                        }
                        else
                        {
                            Console.WriteLine("\nNo es un número mayor a 0.\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nNo es un número.\n");
                    }
                        


                    Console.ReadKey();
                    break;

                case "D" or "d":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Jorge Muñoz - 1177523\n");
                    menu = "D";
                    Console.WriteLine("Hasta pronto :D\n");
                    Console.ReadKey();
                    break;

                default: Console.WriteLine("Letra invalda.");
                    break;

            }

        }
    }
}