﻿using System;

class Program
{
    static void Main(string[] args)

    { // Ponerle un valor a cada variable.

        double numero1;
        double numero2;
        double suma;
        double resta;
        double multiplicacion;
        double division;
        double div;
        double mod;

        Console.WriteLine("Ejercicio 1: Operaciones Aritmeticas \n");

        // Ingresamos ambos números.

        Console.Write("Ingrese el primer número:  ");
        numero1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("\nIngrese el segundo número: ");
        numero2 = Convert.ToDouble(Console.ReadLine());

        // Hacemos cada operación.

        suma = numero1 + numero2;
        resta = numero1 - numero2;
        multiplicacion = numero1 * numero2;
        division = numero1 / numero2;
        div = numero1 / numero2;
        mod = numero1 % numero2;

        // Mostramos los resultados utilizando el formato pedido.

        Console.WriteLine("\n" + numero1 + " + " + numero2 + " = " + suma);
        Console.WriteLine(numero1 + " - " + numero2 + " = " + resta);
        Console.WriteLine(numero1 + " * " + numero2 + " = " + multiplicacion);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + division);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + div);
        Console.WriteLine(numero1 + " % " + numero2 + " = " + mod);

        // Agregamos un mensaje.

        Console.WriteLine("\n\nEjercicio 2: Operaciones Booleanas");

        // Mostrar si el número 1 es mayor que, menor que, o igual al número 2.

        if (numero1 > numero2)
        {
            Console.WriteLine("\n" + numero1 + " > " + numero2);
        }
        else if (numero1 < numero2)
        {
            Console.WriteLine("\n" + numero1 + " < " + numero2);
        }
        else if (numero1 == numero2)
        {
            Console.WriteLine("\nAmbos Números son Iguales");
        }
    }
}